<?php

    include "conn/database.php";
    $db = new database();

    $id_satuan = $_GET['id_satuan'];

    foreach($db->tampil_satuan() as $tampil)
    {
        if($id_satuan == $tampil['id_satuan'])
        {
            foreach(unserialize($tampil['jenis_polarisasi']) as $key => $value)
                $data[] = $value;
        }
    }

    echo json_encode($data);

?>